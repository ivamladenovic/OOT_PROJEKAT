﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Projekat
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private ObservableCollection<Skola> skole;
        private OpenFileDialog openFileDialog;
        private BindingExpression ImeSkoleBE;
        private BindingExpression IDSkoleBE;
        private BindingExpression AdresaSkoleBE;
        private BindingExpression TabelaBE;
        private BindingExpression BESkole;
        private ObservableCollection<Skola> prevuceneSkole = new ObservableCollection<Skola>();
        private ObservableCollection<Ucenik> prevuceniUcenici = new ObservableCollection<Ucenik>();

        private ObservableCollection<Ucenik> listaUcenika = new ObservableCollection<Ucenik>();     

        public ObservableCollection<Skola> Skole
        {
            get { return skole; }
            set
            {
                if (value != null)
                {
                    skole = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Skole)));
                }
            }

        }

        public Skola Posebna { get; set; } = new Skola();

        public Skola Tab2_posebna { get; set; } = new Skola();

        Point startPoint = new Point(); 

        public Skola skolaUcenici { get; set; } = new Skola();  

        public MainWindow()
        {
            InitializeComponent();
            Skole = new ObservableCollection<Skola>();
            UcitajSkole("Skole.txt");
            SkolaKomboBox.DataContext = Skole;
            this.DataContext = Posebna;
            Tabela.DataContext = Posebna;
            Tabela.IsReadOnly = true;
            TabelaSkolaTab3.IsReadOnly = true;
            TabelaUcenikaTab3.IsReadOnly = true;
            ImeSkoleBE = ImeSkoleBox.GetBindingExpression(TextBox.TextProperty);
            IDSkoleBE = IDBox.GetBindingExpression(TextBox.TextProperty);
            AdresaSkoleBE = AdresaBox.GetBindingExpression(TextBox.TextProperty);
            TabelaBE = Tabela.GetBindingExpression(DataGrid.ItemsSourceProperty);
            TabelaSkolaTab3.DataContext = Skole;
            TabelaUcenikaTab3.DataContext = Posebna;
            BESkole = TabelaUcenikaTab3.GetBindingExpression(DataGrid.ItemsSourceProperty);
            Itemc.DataContext = prevuceneSkole;
            Itemc2.DataContext = prevuceniUcenici;


            this.DataContext = skolaUcenici;
            SkolaKomboBox1.DataContext = Skole;    
            SkolaKomboBox2.DataContext = Skole;     
            Upisani1.DataContext = Tab2_posebna;         
            Upisani2.DataContext = Tab2_posebna;         

            listaUcenika1 = new ObservableCollection<Ucenik>();   
            listaUcenika2 = new ObservableCollection<Ucenik>();    

            Upisani1.DataContext = listaUcenika1;      
            Upisani2.DataContext = listaUcenika2;      

        }

        public ObservableCollection<Ucenik> listaUcenika1  
        {
            get;
            set;
        }


        public ObservableCollection<Ucenik> listaUcenika2    
        {
            get;
            set;
        }
        private void SkolaKomboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SkolaKomboBox.SelectedIndex == 0)
            {
                ImeSkoleBox.IsEnabled = false;
                AdresaBox.IsEnabled = false;
                IDBox.IsEnabled = false;
            }
            else
            {
                ImeSkoleBox.IsEnabled = true;
                AdresaBox.IsEnabled = true;
                IDBox.IsEnabled = true;
            }

            Skola novaSkola = SkolaKomboBox.SelectedItem as Skola;
            if (novaSkola != null)
            {
                Posebna.ImeSkole = novaSkola.ImeSkole;
                Posebna.Id = novaSkola.Id;
                Posebna.AdresaSkole = novaSkola.AdresaSkole;
                Posebna.Ucenici = novaSkola.Ucenici;
                ImeSkoleBE.UpdateTarget();
                IDSkoleBE.UpdateTarget();
                AdresaSkoleBE.UpdateTarget();

                try
                {

                    Uri imageUri = new Uri(novaSkola.IkonicaSkole, UriKind.RelativeOrAbsolute);
                    Ikonica.Source = new BitmapImage(imageUri);

                }
                catch (Exception)
                {
                    Ikonica.Source = null;
                }

            }
            TabelaBE.UpdateTarget();
            ImeUcenikaBox.Text = "";
            PrezimeUcenikaBox.Text = "";
            AdresaUcenikaBox.Text = "";
            JMBGUcenikaBox.Text = "";
            IkonicaUcenika.Source = null;
        }

        private void DodajSkolu_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = int.Parse(IDBox.Text);
                if (Skole.Where(x => int.Parse(x.Id) == id).Any())
                {
                    MessageBox.Show("Id skole vec postoji.");
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Morate uneti broj." + ex.Message);
                return;
            }

            ImeSkoleBE.UpdateSource();
            IDSkoleBE.UpdateSource();
            AdresaSkoleBE.UpdateSource();

            Skola novaSkola = new Skola
            {
                Id = Posebna.Id,
                ImeSkole = Posebna.ImeSkole,
                AdresaSkole = Posebna.AdresaSkole
            };

            if (string.IsNullOrEmpty(novaSkola.IkonicaSkole))
            {
                openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Slike|*.jpg;*.png;*.gif|Sve datoteke|*.*";

                if (openFileDialog.ShowDialog() == true)
                {
                    novaSkola.IkonicaSkole = GetRelativePath(Directory.GetCurrentDirectory(), openFileDialog.FileName);

                }
            }
            else
            {
                Ikonica.Source = new BitmapImage(new Uri(novaSkola.IkonicaSkole));
            }

            Skole.Add(novaSkola);

            SkolaKomboBox.ItemsSource = null;
            SkolaKomboBox.ItemsSource = Skole;
            Ikonica.Source = null;
            ImeSkoleBox.Text = "";
            AdresaBox.Text = "";
            IDBox.Text = "";
        }
        private void IzmeniSkolu_Click(object sender, RoutedEventArgs e)
        {

            ObservableCollection<Skola> noveSkole = new ObservableCollection<Skola>();

            foreach (Skola s in Skole)
            {

                noveSkole.Add(s);

            }
            var Izmeniti = noveSkole.Where(x => x.Id == Posebna.Id).FirstOrDefault();
            Izmeniti.ImeSkole = ImeSkoleBox.Text;
            Izmeniti.AdresaSkole = AdresaBox.Text;


            Ikonica.Source = null;

            SkolaKomboBox.Text = Izmeniti.ImeSkole;
            Skole = noveSkole;
            SkolaKomboBox.Items.Refresh();
            ImeSkoleBox.Text = "";
            AdresaBox.Text = "";
            IDBox.Text = "";

        }

        private void IzbrisiSkolu_Click(object sender, RoutedEventArgs e)
        {

            var Obrisati = Skole.Where(x => x.ImeSkole == Posebna.ImeSkole).FirstOrDefault();
            if(Obrisati.ImeSkole == "NEUPISANI")
            {
                MessageBox.Show("Ne mozete brisati neupisane!");
            }
            else
            {
                var NeupisaniSchool = Skole.FirstOrDefault(x => x.ImeSkole == "NEUPISANI");

                foreach (var ucenik in Obrisati.Ucenici)
                {
                    NeupisaniSchool.Ucenici.Add(ucenik);
                }
                Skole.Remove(Obrisati);

            }
                       
            var dataSource = Tabela.ItemsSource as ObservableCollection<Ucenik>;
            dataSource.Clear();

            Ikonica.Source = null;
            ImeSkoleBox.Text = "";
            AdresaBox.Text = "";
            IDBox.Text = "";

            SkolaKomboBox.ItemsSource = null;
            SkolaKomboBox.ItemsSource = Skole;

        }

        private void Tabela_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Tabela.SelectedItem is Ucenik prikaziUcenika)
            {
                if (prikaziUcenika != null)
                {
                    ImeUcenikaBox.Text = prikaziUcenika.ImeUcenika;
                    PrezimeUcenikaBox.Text = prikaziUcenika.PrezimeUcenika;
                    JMBGUcenikaBox.Text = prikaziUcenika.JmbgUcenika;
                    AdresaUcenikaBox.Text = prikaziUcenika.AdresaUcenika;
                    try
                    {
                        if (!string.IsNullOrEmpty(prikaziUcenika.IkonicaUcenika))
                        {
                            Uri imageUri = new Uri(prikaziUcenika.IkonicaUcenika, UriKind.RelativeOrAbsolute);
                            IkonicaUcenika.Source = new BitmapImage(imageUri);
                        }
                        else
                        {
                            IkonicaUcenika.Source = null;
                        }
                    }
                    catch (Exception)
                    {
                        Ikonica.Source = null;
                    }

                }
            }
        }

        private void IzbrisiUcenika_Click(object sender, RoutedEventArgs e)
        {
            var selectedUcenik = (Ucenik)Tabela.SelectedItem;

            if (selectedUcenik != null)
            {
                Posebna.Ucenici.Remove(selectedUcenik);
                Skola s = Skole.Where(x => x.ImeSkole == "NEUPISANI").FirstOrDefault();
                s.Ucenici.Add(selectedUcenik);
            }
            else
            {
                MessageBox.Show("Nema ucenika na listi koga mozete izbrisati");
            }

            IkonicaUcenika.Source = null;

            ImeUcenikaBox.Text = "";
            PrezimeUcenikaBox.Text = "";
            JMBGUcenikaBox.Text = "";
            AdresaUcenikaBox.Text = "";
        }

        private void IzmeniUcenika_Click(object sender, RoutedEventArgs e)
        {
            if (!DaLiJeJMBG(JMBGUcenikaBox.Text))
            {
                MessageBox.Show("Forma JMBG-a nije ispravna");
                return;
            }

            var selectedUcenik = (Ucenik)Tabela.SelectedItem;

            foreach (Skola s in Skole)
            {
                if (s.Ucenici.Where(x => x.JmbgUcenika == JMBGUcenikaBox.Text && x != selectedUcenik).Any())
                {

                    MessageBox.Show("Ne mozete dodati vec postojaci JMBG!");
                    return;
                }
            }
            if (selectedUcenik != null)
            {
                selectedUcenik.ImeUcenika = ImeUcenikaBox.Text;
                selectedUcenik.PrezimeUcenika = PrezimeUcenikaBox.Text;
                selectedUcenik.JmbgUcenika = JMBGUcenikaBox.Text;
                selectedUcenik.AdresaUcenika = AdresaUcenikaBox.Text;

            }
            IkonicaUcenika.Source = null;

            ImeUcenikaBox.Text = "";
            PrezimeUcenikaBox.Text = "";
            JMBGUcenikaBox.Text = "";
            AdresaUcenikaBox.Text = "";
        }

        private void DodajUcenika_Click(object sender, RoutedEventArgs e)
        {
            string selectedImagePath = "";
            openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Slike|*.jpg;*.png;*.gif|Sve datoteke|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                selectedImagePath = GetRelativePath(Directory.GetCurrentDirectory(), openFileDialog.FileName);
            }

            if (!DaLiJeJMBG(JMBGUcenikaBox.Text))
            {
                MessageBox.Show("Forma JMBG-a nije ispravna");
                return;
            }

            foreach (Skola s in Skole)
            {
                if (s.Ucenici.Where(x => x.JmbgUcenika == JMBGUcenikaBox.Text).Any())
                {
                    MessageBox.Show("Ne mozete dodati vec postojaci JMBG!");
                    return;
                }
            }

            Ucenik tempUcenik = new Ucenik
            {
                ImeUcenika = ImeUcenikaBox.Text,
                PrezimeUcenika = PrezimeUcenikaBox.Text,
                JmbgUcenika = JMBGUcenikaBox.Text,
                AdresaUcenika = AdresaUcenikaBox.Text,
                IkonicaUcenika = selectedImagePath
            };
            Posebna.Ucenici.Add(tempUcenik);
            IkonicaUcenika.Source = null;
            ImeUcenikaBox.Text = "";
            PrezimeUcenikaBox.Text = "";
            JMBGUcenikaBox.Text = "";
            AdresaUcenikaBox.Text = "";

        }
        public static bool DaLiJeJMBG(string jmbg)
        {
            if (jmbg.Length != 13 || !long.TryParse(jmbg, out long number))
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        protected override void OnClosing(CancelEventArgs e)
        {
            SacuvajSkole("Skole.txt");
            base.OnClosing(e);
        }

        private void UcitajSkole(string putanja)
        {
            try
            {
                if (File.Exists(putanja))
                {
                    string[] lines = File.ReadAllLines(putanja);
                    for (int i = 0; i < lines.Length; i++)
                    {
                        string[] delovi = lines[i].Split(',');
                        int br_ucenika = int.Parse(delovi[4]);
                        Skola novaSkola = new Skola { Id = delovi[0], ImeSkole = delovi[1], AdresaSkole = delovi[2], IkonicaSkole = delovi[3], Ucenici = new ObservableCollection<Ucenik>() };
                        if (br_ucenika > 0)
                        {
                            for (int j = 1; j <= br_ucenika; j++)
                            {
                                string[] deloviUcenika = lines[j + i].Split(',');
                                novaSkola.Ucenici.Add(new Ucenik { ImeUcenika = deloviUcenika[0], PrezimeUcenika = deloviUcenika[1], AdresaUcenika = deloviUcenika[2], JmbgUcenika = deloviUcenika[3], IkonicaUcenika = deloviUcenika[4] });

                            }
                            i += br_ucenika;
                        }

                        Skole.Add(novaSkola);
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Doslo je do greske prilikom ucitavanja skole iz fajla");
            }
        }

        private void SacuvajSkole(string putanja)
        {
            List<string> rez = new List<string>();
            foreach (Skola s in skole)
            {
                rez.Add(string.Format("{0},{1},{2},{3},{4}", s.Id, s.ImeSkole, s.AdresaSkole, s.IkonicaSkole, s.Ucenici.Count));
                foreach (Ucenik u in s.Ucenici)
                {
                    rez.Add(string.Format("{0},{1},{2},{3},{4}", u.ImeUcenika, u.PrezimeUcenika, u.AdresaUcenika, u.JmbgUcenika, u.IkonicaUcenika));
                }
            }
            File.WriteAllLines(putanja, rez.ToArray());
        }

        public static string GetRelativePath(string basePath, string targetPath)
        {
            Uri baseUri = new Uri(basePath);
            Uri targetUri = new Uri(targetPath);
            Uri relativeUri = baseUri.MakeRelativeUri(targetUri);
            return Uri.UnescapeDataString(relativeUri.ToString());
        }

        private void TabelaSkolaTab3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Skola novaSkola = TabelaSkolaTab3.SelectedItem as Skola;
            if (novaSkola != null)
            {
                TabelaUcenikaTab3.DataContext = novaSkola;
                BESkole.UpdateTarget();
            }
        }
        private void DataGrid_MouseMove(object sender, MouseEventArgs e)
        {
            if (!(sender is DataGrid dataGrid)) return;

            if (dataGrid.SelectedItem is Skola skola && e.LeftButton == MouseButtonState.Pressed)
            {
                DragDropData dragData = new DragDropData(skola, DragDropEffects.Copy);
                DragDrop.DoDragDrop(dataGrid, dragData, DragDropEffects.Copy);
            }
            else if(dataGrid.SelectedItem is Ucenik ucenik && e.LeftButton == MouseButtonState.Pressed)
            {
                DragDropData dragData = new DragDropData(ucenik, DragDropEffects.Copy);
                DragDrop.DoDragDrop(dataGrid, dragData, DragDropEffects.Copy);
            }
        }

        private void Image_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(typeof(DragDropData)))
            {
                var dragDropData = e.Data.GetData(typeof(DragDropData)) as DragDropData;

                if (dragDropData != null)
                {
                    if(dragDropData.Data is Skola)
                    {
                        Skola skola = dragDropData.Data as Skola;
                        if (skola != null)
                        {
                            if (prevuceneSkole.Contains(skola))
                            {
                                prevuceneSkole.Remove(skola);
                            }
                            Point mesto = e.GetPosition(sender as Image);
                            skola.Left = mesto.X;
                            skola.Top = mesto.Y;
                            prevuceneSkole.Add(skola);
                            
                        }
                    }
                    else if(dragDropData.Data is Ucenik)
                    {
                        Ucenik ucenik = dragDropData.Data as Ucenik;
                        if(ucenik != null)
                        {
                            if (prevuceniUcenici.Contains(ucenik))
                            {
                                prevuceniUcenici.Remove(ucenik);
                            }
                            Point mesto = e.GetPosition(sender as Image);
                            ucenik.Left = mesto.X;
                            ucenik.Top = mesto.Y;
                            prevuceniUcenici.Add(ucenik);
                        }
                    }
                    
                }
            }
        }

        private Skola GetSkolaFromImage(Image imgSkola)
        {
            string ikonicaPutanja = (imgSkola.Source as BitmapImage)?.UriSource?.OriginalString;
            if (ikonicaPutanja != null)
            {
                foreach (Skola skola in skole)
                {
                    if (skola.IkonicaSkole == ikonicaPutanja)
                    {
                        return skola;
                    }
                }
            }

            return null;
        }

        private void Image_MouseMove(object sender, MouseEventArgs e)
        {
            if (!(sender is Image imgSkola)) return;

            Skola skola = GetSkolaFromImage(imgSkola);
            if (skola != null && e.LeftButton == MouseButtonState.Pressed)
            {
                DragDropData dragData = new DragDropData(skola, DragDropEffects.Copy);
                DragDrop.DoDragDrop(imgSkola, dragData, DragDropEffects.Copy);
            }
        }

        public class DragDropData
        {
            public object Data { get; set; }
            public DragDropEffects Effects { get; set; }

            public DragDropData(object data, DragDropEffects effects)
            {
                Data = data;
                Effects = effects;
            }
        }
        private void IzbrisiPotpuno_Click(object sender, RoutedEventArgs e)
        {

            var sk = (e.Source as MenuItem).DataContext as Skola;
            prevuceneSkole.Remove(sk);
            skole.Remove(sk);
            
        }

        private void IzbrisiSaMape_Click(object sender, RoutedEventArgs e)
        {


            var sk = (e.Source as MenuItem).DataContext as Skola;
            prevuceneSkole.Remove(sk);
        }
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            var u = (e.Source as MenuItem).DataContext as Ucenik;
            prevuceniUcenici.Remove(u);
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            var u = (e.Source as MenuItem).DataContext as Ucenik;
            prevuceniUcenici.Remove(u);

            var sk = this.TabelaUcenikaTab3.DataContext as Skola;
            sk.Ucenici.Remove(u);
        }


        private void SkolaKomboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Skola izabranaSkola = SkolaKomboBox1.SelectedItem as Skola;

            if (izabranaSkola != null)
            {
                List<Ucenik> ucenici = IspisiUcenike(izabranaSkola);
                Upisani1.ItemsSource = ucenici;

            }

        }

        private void SkolaKomboBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           Skola izabranaSkola = SkolaKomboBox2.SelectedItem as Skola;

            if (izabranaSkola != null)
            {
                List<Ucenik> ucenici = IspisiUcenike(izabranaSkola);
                Upisani2.ItemsSource = ucenici;

            }
        }

        private List<Ucenik> IspisiUcenike(Skola izabranaSkola)
        {
            List<Ucenik> ucenici = new List<Ucenik>();

            string[] lines = File.ReadAllLines("Skole.txt");

            bool preuzmi = false;

            foreach (string line in lines)
            {
                if (line.StartsWith(izabranaSkola.Id.ToString()))
                {
                    preuzmi = true;
                    continue;
                }

                if (preuzmi)
                {
                    string[] parts = line.Split(',');

                    if (parts.Length == 5)
                    {
                        string ucenikIme = parts[0].Trim();
                        string ucenikPrezime = parts[1].Trim();
                        string ucenikAdresa = parts[2].Trim();
                        string ucenikJMBG = parts[3].Trim();
                        string ucenikIkonica = parts[4].Trim();

                        if (int.TryParse(ucenikIme, out _))
                        {
                            break;
                        }

                        ucenici.Add(new Ucenik
                        {
                            ImeUcenika = ucenikIme,
                            PrezimeUcenika = ucenikPrezime,
                            AdresaUcenika = ucenikAdresa,
                            JmbgUcenika = ucenikJMBG,
                            IkonicaUcenika = ucenikIkonica
                        });

                    }
                }

            }

            return ucenici;
            
        }


        private static T FindAncestor<T>(DependencyObject current) where T : DependencyObject
        {
            do
            {
                if (current is T)
                {
                    return (T)current;
                }
                current = VisualTreeHelper.GetParent(current);
            }
            while (current != null);
            return null;
        }

        private void Upisani2_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            startPoint = e.GetPosition(null);
        }

        private void Upisani2_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePos = e.GetPosition(null);
            Vector diff = startPoint - mousePos;

            if (e.LeftButton == MouseButtonState.Pressed &&
                (Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance ||
                Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance))
            {
                // Get the dragged ListViewItem
                ListView listView = sender as ListView;
                ListViewItem listViewItem =
                    FindAncestor<ListViewItem>((DependencyObject)e.OriginalSource);

                // Find the data behind the ListViewItem
                Ucenik student = (Ucenik)listView.ItemContainerGenerator.
                    ItemFromContainer(listViewItem);

                // Initialize the drag & drop operation
                DataObject dragData = new DataObject("myFormat", student);
                DragDrop.DoDragDrop(listViewItem, dragData, DragDropEffects.Move);
            }
        }

        private void Upisani2_DragEnter(object sender, DragEventArgs e)
        {
            if (!e.Data.GetDataPresent("myFormat") || sender == e.Source)
            {
                e.Effects = DragDropEffects.None;
            }
        }

        private void Upisani2_Drop(object sender, DragEventArgs e)
        {
           if (e.Data.GetDataPresent("myFormat"))
            {
                Ucenik ucenik = e.Data.GetData("myFormat") as Ucenik;


                Skola skola1 = (Skola)SkolaKomboBox1.SelectedItem;
                Skola skola2 = (Skola)SkolaKomboBox2.SelectedItem;

                if (skola1 == skola2)
                {
                    MessageBox.Show("Izabrana je dva puta ista skola.");
                }

                if (skola1 != null && skola2 != null && skola1 != skola2)
                {


                    if (!skola2.Ucenici.Contains(ucenik))
                    {
                        skola2.Ucenici.Add(ucenik);
                        skola1.Ucenici.Remove(ucenik);
                    }

                    Upisani1.ItemsSource = null;
                    Upisani1.ItemsSource = skola1.Ucenici;

                    Upisani2.ItemsSource = null;
                    Upisani2.ItemsSource = skola2.Ucenici;

                }
            }
        }
        private void Upisani1_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
           startPoint = e.GetPosition(null);
        }

        private void Upisani1_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePos = e.GetPosition(null);
            Vector diff = startPoint - mousePos;

            if (e.LeftButton == MouseButtonState.Pressed &&
                (Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance ||
                Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance))
            {
                // Get the dragged ListViewItem
                ListView listView = sender as ListView;
                ListViewItem listViewItem =
                    FindAncestor<ListViewItem>((DependencyObject)e.OriginalSource);

                // Find the data behind the ListViewItem
                Ucenik student = (Ucenik)listView.ItemContainerGenerator.
                    ItemFromContainer(listViewItem);

                // Initialize the drag & drop operation
                DataObject dragData = new DataObject("myFormat", student);
                DragDrop.DoDragDrop(listViewItem, dragData, DragDropEffects.Move);
            }
        }

        private void Upisani1_DragEnter(object sender, DragEventArgs e)
        {
           if (!e.Data.GetDataPresent(typeof(Ucenik)) || sender == e.Source)
           {
                e.Effects = DragDropEffects.None;
           }
        }

        private void Upisani1_Drop(object sender, DragEventArgs e)
        {
           if (e.Data.GetDataPresent("myFormat"))
            {
                Ucenik ucenik = e.Data.GetData("myFormat") as Ucenik;


                Skola skola1 = (Skola)SkolaKomboBox1.SelectedItem;
                Skola skola2 = (Skola)SkolaKomboBox2.SelectedItem;

                if (skola1 == skola2)
                {
                    MessageBox.Show("Izabrana je dva puta ista skola.");
                }

                if (skola1 != null && skola2 != null && skola1 != skola2)
                {
                    if (!skola1.Ucenici.Contains(ucenik))
                    {
                        skola1.Ucenici.Add(ucenik);
                    }

                    Upisani1.ItemsSource = null;
                    Upisani1.ItemsSource = skola1.Ucenici;

                    Upisani2.ItemsSource = null;
                    Upisani2.ItemsSource = skola2.Ucenici;

                    bool isRemoved = skola2.Ucenici.Remove(ucenik);


                    if (!isRemoved)
                    {
                        isRemoved = skola2.Ucenici.Remove(ucenik);
                    }
                }
            }
        }

    }

}


 
