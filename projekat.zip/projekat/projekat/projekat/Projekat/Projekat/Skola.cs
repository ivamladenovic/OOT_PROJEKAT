﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace Projekat
{
    public class Skola : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private string id;
        private string adresaSkole;
        private string imeSkole;
        private string ikonica;
        public string Id
        {
            get { return id; }
            set
            {
                if(value != id)
                {
                    id = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Id)));
                }
            }

        }
        public string ImeSkole
        {
            get { return imeSkole; }
            set
            {
                if (value != imeSkole)
                {
                    imeSkole = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ImeSkole)));
                }
            }

        }

        public string AdresaSkole
        {
            get { return adresaSkole; }
            set
            {
                if (value != adresaSkole)
                {
                    adresaSkole = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(AdresaSkole)));
                }
            }

        }
        public string IkonicaSkole
        {
            get { return ikonica; }
            set
            {
                if (value != ikonica)
                {
                    ikonica = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IkonicaSkole)));
                }
            }

        }
        public ObservableCollection<Ucenik> Ucenici { get; set; } = new ObservableCollection<Ucenik>();

        

        public override string ToString()
        {
            return ImeSkole + " " + AdresaSkole;
        }
        public double Left { get; set; } // Dodato svojstvo Left
        public double Top { get; set; }

        public override bool Equals(object o)
        {
            // If the passed object is null, return False
            if (o == null || this == null)
            {
                return false;
            }
            // If the passed object is not Customer Type, return False
            if (!(o is Skola))
            {
                return false;
            }

            if (id == null)
            {
                return false;
            }



            return id.Equals(((Skola)o).id);
        }

    }
}
