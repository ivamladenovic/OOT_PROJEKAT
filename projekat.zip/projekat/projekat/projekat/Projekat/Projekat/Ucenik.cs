﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat
{
    public class Ucenik : INotifyPropertyChanged
    {
        private string imeUcenika;
        private string prezimeUcenika;
        private string adresaUcenika;
        private string ikonicaUcenika;
        private string jmbgUcenika;

        public string IkonicaUcenika
        {
            get { return ikonicaUcenika; }
            set
            {
                if (value != ikonicaUcenika)
                {
                    ikonicaUcenika = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IkonicaUcenika)));
                }
            }

        }
        public string AdresaUcenika
        {
            get { return adresaUcenika; }
            set
            {
                if(value != adresaUcenika)
                {
                    adresaUcenika = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(AdresaUcenika)));
                }
            }
        }
        public string JmbgUcenika
        {
            get { return jmbgUcenika; }
            set
            {
                if (value != jmbgUcenika)
                {
                    jmbgUcenika = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(JmbgUcenika)));
                }
            }
        }

        public string ImeUcenika 
        {
            get { return imeUcenika; }
            set
            {
                if (value != imeUcenika)
                {
                    imeUcenika = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ImeUcenika)));
                }

            }
        }

        public string PrezimeUcenika
        {
            get { return prezimeUcenika; }
            set
            {
                if (value != prezimeUcenika)
                {
                    prezimeUcenika = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PrezimeUcenika)));
                }

            }
        }
        public double Left { get; set; } // Dodato svojstvo Left
        public double Top { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        public override bool Equals(object o) {
            // If the passed object is null, return False
            if (o == null)
            {
                return false;
            }
            // If the passed object is not Customer Type, return False
            if (!(o is Ucenik))
            {
                return false;
            }

            if (jmbgUcenika == null)
            {
                return false;
            }

            return jmbgUcenika.Equals(((Ucenik)o).jmbgUcenika);
        }
    }

    
}
